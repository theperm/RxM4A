﻿using System;
using System.Linq;
using Microsoft.Evtx;

namespace TxSamples.EvtxRaw
{
    class Program
    {
        static void Main(string[] args)
        {
            var en = EvtxEnumerable.FromFiles(@"..\..\..\HTTP_Server.evtx");

            int count = en.Count();

            Console.WriteLine(count);
        }
    }
}
