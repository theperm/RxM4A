﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Evtx;
using System.Diagnostics.Eventing.Reader;

namespace TxSamples.EvtxRaw
{
    class Program
    {
        static void Main()
        {
            IEnumerable<EventRecord> evtx = EvtxEnumerable.FromFiles(@"..\..\..\HTTP_Server.evtx");
            Console.WriteLine(evtx.Count());
        }
    }
}
